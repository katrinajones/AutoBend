#Script for setting up an autobend model
#Katrina Jones 8.17.2022
#See AutoBend_Documentation.docx

import maya.cmds as cmds
from maya.api.OpenMaya import MVector, MMatrix, MPoint
import numpy as np
import maya.api.OpenMaya as om2
import Automated_bending_functions as ab#source automated bending functions

####################################################################################
#Assemble joints
#Import verts and label V1,V2,V3 etc
#Import CORs and label COR1, COR2, COR3 etc
#Create axes and label axes1, axes2, axes3 etc

#1. detect joints
joints = cmds.ls('axes*',type='surfaceShape')#NOT working
joints = list(map(lambda sub:int(''.join( 
      [ele for ele in sub if ele.isnumeric()])), joints))
njoint = len(joints)
#find all the "end" positions
ends = np.diff(joints)>1
ends = [i for i, x in enumerate(ends) if x]
ends.append(njoint-1)

#######################################################################################

#2. Make analysis objects
for i in joints:
   
    make_objects(i)

#Reorient each axes with red point caudally, green point dorsally, and blue point to the right
#Position locators on the zygapophyses and centra

#########################################################################################

#3. set up the parenting
#duplicate vertebrae - need to duplicate because making the boolean object deletes the original model

for i in joints:
    ant=str(i)
    post=str(i+1)
    Post = 'V'+post+':Mesh'
    Post1 = 'V'+post+'post'
    Ant = 'V'+ant+':Mesh'
    Ant1 = 'V'+ant+'ant'

   
    duplicate_verts(Ant, Post, Ant1, Post1)

#Set up parenting
for i in joints: 
    ant=str(i)
    post=str(i+1)
    base_axis = 'axes'+ant
    new_axis = 'COR_locator'+ant
    Post = 'V'+post+':Mesh'
    Post1 = 'V'+post+'post'
    Ant = 'V'+ant+':Mesh'
    Ant1 = 'V'+ant+'ant'
    Zyg_ant = 'Zyg_ant'+ant
    Zyg_post = 'Zyg_post'+ant
    inter = 'Inter'+ant
    cent_D='cent_D'+ant
    cent_V='cent_V'+ant
    cent_L='cent_L'+ant
    cent_R='cent_R'+ant
    Pcent_D='Pcent_D'+ant
    Pcent_V='Pcent_V'+ant
    Pcent_L='Pcent_L'+ant
    Pcent_R='Pcent_R'+ant
    
    set_up_sub_joint(base_axis, new_axis, Post, Post1, Ant, Ant1, Zyg_ant, Zyg_post, inter, 
    cent_D, cent_V, cent_L, cent_R, Pcent_D, Pcent_V, Pcent_L, Pcent_R)

#######################################################################################

#4. calculate average vertebral area and spacing

Area_all= []
spacing_all=[]
test_all=[]
for i in joints:
    ant=str(i)
    post=str(i+1)
    Ant = 'V'+ant+':Mesh'
    Post = 'V'+post+':Mesh'
    COR1 = 'COR_locator'+ant
    COR2 = 'COR_locator'+post
    
    #vertebral area averaged by joint
    v_area_ant = cmds.polyEvaluate(Ant,a=True)
    v_area_post = cmds.polyEvaluate(Post,a=True)
    v_area = (v_area_ant+ v_area_post)/2
    Area_all.append(v_area)
      
  
    #intervertebral spacing
    ddist = wDist("cent_D"+ant,"Pcent_D"+ant, COR1)
    vdist = wDist("cent_V"+ant,"Pcent_V"+ant, COR1)
    ldist = wDist("cent_L"+ant,"Pcent_L"+ant, COR1)
    rdist = wDist("cent_R"+ant,"Pcent_R"+ant, COR1)
    dis = np.mean([ddist,vdist,ldist,rdist])
    spacing_all.append(dis)
    
    ddist = wDist("cent_D"+ant,"cent_V"+ant, COR1)
    test_all.append(ddist)
    

v_area = np.mean(Area_all)
j_space = np.mean(spacing_all)

#######################################################

#5. initial run
#Starting parameters
Transl=False #No translation alllowed
zyg_strain=0.5 #Zygapophysis strain
cent_strain=0.5 #Centrum Strain
Condit=[True, True] #Include both zygapophysis and centrum constraints
it=0.0025 #intersection threshold

for i in joints:

        jointname = str(i) + '_' + str(i+1)
        test = ab.digital_bending(joint=i, angle=0.5, it=it, cent_strain=cent_strain, zyg_strain, v_area=v_area, ZygTest= Condit[0], CentTest= Condit[1], Transl=Transl)
        output = [jointname, it, js, cent_strain,zyg_strain,Transl, Transl_fact, Condit]
        output = output + test
